#pragma once

#include "skse64_common/Relocation.h"
#include "skse64/NiRenderer.h"

void Hooks_NetImmerse_Init(void);
void Hooks_NetImmerse_Commit(void);

